using System;

class Program {
  public static void Main (string[] args) {
    Console.WriteLine ("Ola este algoritmo fara a soma de dois numeros naturais.");

    int a;//declaração da variável 'a'
      
    int b;//declaração da variável 'b'

    do{//início do laço de repetição do-while
      Console.Write("\nDigite um numero inteiro positivo: ");
      a = int.Parse(Console.ReadLine());//valor digitado é atribuído à 'a'
    }while(a < 0);//verificação do valor se é natural, em caso de true, permanece atribuído à 'a', em caso de false, repete o laço
      
    do{//início do laço de repetição do-while
      Console.Write("\nDigite um numero inteiro positivo: ");
      b = int.Parse(Console.ReadLine());//valor digitado é atribuído à 'b'
    }while(b < 0);//verificação do valor se é natural, em caso de true, é atribuído à 'b', em caso de false, repete o laço

    int c = a + b;//declaração e atribuição de valor da variável 'c'
      
    Console.WriteLine("\nSoma das variáveis "+a+" e "+b+" = " +c);//escreve a soma das variáveis 'a' e 'b', atribuídas à 'c' no console
  }
}