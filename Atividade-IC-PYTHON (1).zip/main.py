print ("Ola este algoritmo fara a soma de dois numeros naturais")#informa o usuário o que o algoritmo se propõe a fazer

a = 0#inicialização da variável 'a'
b = 0#inicialização da variável 'b'

a = int(input("\nDigite um numero inteiro positivo: "))#valor digitado é atribuído à 'a'
while a < 0:#verificação se o valor de 'a' respeita a condição 
  a = int(input("\nDigite um numero inteiro positivo: "))
  
b = int(input("\nDigite um numero inteiro positivo: "))#valor digitado é atribuído à 'b'
while b < 0:#verificação se o valor de 'b' respeita a condição 
  b = int(input("\nDigite um numero inteiro positivo: "))
      
c = a + b#inicialização e atribuição de valor à variável 'c'
    
print ("\n", a, "+", b,"=", c)#escreve o valor da soma das variáveis 'a' e 'b', atribuídas à 'c' no console