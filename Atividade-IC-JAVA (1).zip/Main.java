import java.util.Scanner;
public class Main {//classe main
    public static void main(String[] args) {//função main
      
      Scanner ler = new Scanner(System.in);

      System.out.println("Ola este algoritmo fara a soma de dois numeros naturais.");//informa o usuário o que o algoritmo se propõe a fazer
      
      int a;//declaração da variável 'a'
      
      int b;//declaração da variável 'b'

      do{//início do laço de repetição do-while
        System.out.println("\nDigite um numero inteiro positivo: ");
        a = ler.nextInt();//valor digitado é atribuído à 'a'
      }while(a < 0);//verificação do valor se é natural, em caso de true, permanece atribuído à 'a', em caso de false, repete o laço
      
      do{//início do laço de repetição do-while
        System.out.printf("\nDigite um numero inteiro positivo: \n");
        b = ler.nextInt();//valor digitado é atribuído à 'b'
      }while(b < 0);//verificação do valor se é natural, em caso de true, é atribuído à 'b', em caso de false, repete o laço

      int c = a + b;//declaração e atribuição de valor da variável 'c'
      
        System.out.printf("\nSoma das variáveis A e B = %d",(c));//escreve a variável 'c' no console
    }
}