#include <iostream>//declaração de bibliotecas

int leNatural();//prototipação da função leNatural

int main()//função main
{
  std::cout<<"Ola este algoritmo fara a soma de dois numeros naturais.";//informa o usuário o que o algoritmo se propõe a fazer
  int a = leNatural();//valor da função leNatural é recebido por 'a'
  int b = leNatural();//valor da função leNatural é recebido por 'b'
  
  int c = a + b;//soma de 'a' e 'b' atribuida à variável 'c'
  
  std::cout<< "\n"<<c;//escreve o valor da variável 'c' no console
  
  return 0;
}

int leNatural(){//função que lê um número natural
  int x;//declaração da variável 'x'
  
  do{//início do laço de repetição do-while
  std::cout<<"\nDigite um numero inteiro positivo: ";
  std::cin>> x;//valor digitado é atribuído à 'x'
  }while(x < 0);//verificação se o valor de 'x' respeita a condição e fim do laço do-while
  
  return x;//retorna o valor da variável 'x' para a função main
}